import React from 'react'
import { Link } from 'react-router-dom'

function Home(props) {
  return (
    <>
      <h2>
        Home page
      </h2>
      
      <Link to="/daftarproduk">Menuju Daftar Produk</Link>
    </>
  )
}

export default Home