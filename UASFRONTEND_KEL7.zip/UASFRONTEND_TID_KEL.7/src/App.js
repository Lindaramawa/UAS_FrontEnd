import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Sayur from './components/Sayur';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Header />
        <div className="container mt-4">
          <Sayur />
        </div>
    </div>
  )
}
export default App;