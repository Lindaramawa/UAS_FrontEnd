let invoices = [
    {
      name: "Wortel",
      number: 1,
      amount: "1.000",
      due: "14/12/2021"
    },
    {
      name: "Brokoli",
      number: 2,
      amount: "3.000",
      due: "14/12/2000"
    },
    {
      name: "Merica",
      number: 3,
      amount: "1.000",
      due: "14/12/2021"
    },
    {
      name: "Apel",
      number: 4,
      amount: "20.000",
      due: "14/12/2021"
    },
    {
      name: "Pepaya",
      number: 5,
      amount: "10.000",
      due: "14/12/2021"
    }
  ];
  
  export function getInvoices() {
    return invoices;
  }

  export function getInvoice(number) {
    return invoices.find(
      invoice => invoice.number === number
    );
  }