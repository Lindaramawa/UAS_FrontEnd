export default function Expenses() {
    return (
      <main style={{ padding: "1rem 0" }}>
        <h2>Home</h2>
        <h3>Mbak Yur adalah sebuah website yang sangatlah praktis untuk para masyarakat milenial saat ini!</h3>
      </main>
    );
  }