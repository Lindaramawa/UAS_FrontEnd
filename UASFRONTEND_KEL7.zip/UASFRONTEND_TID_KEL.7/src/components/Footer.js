import React from 'react';
import styled from 'styled-components';

const footer = () => {
    return(
    <FooterContainer className="main-footer">
        <div className="footer-bottom"> 
                    <p className="text-xs-center"> 
                        &copy;{new Date().getFullYear()} - MBAK YURR 
                    </p> 
                </div> 

</FooterContainer>

);
}
export default footer

const FooterContainer = styled.footer`
.footer-middle {
    background: var(--mainWhite);
    padding-top: 3rem;
    color: var(--mainDark);
}

.footer-bottom {
    background: var(--mainWhite);
    padding-left: 38rem;
    padding-right: 6rem;
    padding-top: 3rem;
    padding-botton: 2rem;
}
`;