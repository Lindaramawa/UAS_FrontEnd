import react from "react";
import ReactDOM from "react-dom";

export const UTS = () => <h1>Macam-Macam Bahasa yang Pernah Kupelajari Saat Kuliah</h1>

//export default UTS