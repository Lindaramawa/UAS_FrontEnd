import { Card, Row, Col } from 'react-bootstrap';
import sayur1 from './wortel.jpg';
import sayur2 from './kentang.jpg';

const sayur = () => {
    return(
        <Row xs={1} md={2} className="g-4">
            {Array.from({ length: 2 }).map((_, idx) => (
            <Col>
            <Card>
                <Card.Img variant="top" src={sayur1} />
                <Card.Body>
                    <Card.Title>Wortel</Card.Title>
                    <Card.Text>
                        <p>2.000/biji</p>
                        <p>Bu Santi</p>
                        <p>23/12/2021</p>
                    </Card.Text>
                </Card.Body>
                <Card.Img variant="right" src={sayur2} />
                <Card.Body>
                    <Card.Title>Kentang</Card.Title>
                    <Card.Text>
                        <p>3.000/biji</p>
                        <p>Bu Sari</p>
                        <p>23/12/2021</p>
                    </Card.Text>
                </Card.Body>
            </Card>
            </Col>
            ))}
        </Row>
    );
}

export default sayur