
import {Navbar, Nav, NavDropdown, Container } from "react-bootstrap";

const navbar = () => {
    return(
      <Navbar bg="success" expand="lg">
  <Container>
    <Navbar.Brand href="#home">Mbak Yurr</Navbar.Brand>
    <Navbar.Toggle aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="me-auto">
        <Nav.Link href="/home">Home</Nav.Link>
        <Nav.Link href="/masak">Tentang</Nav.Link>
        <NavDropdown title="Daftar Produk" id="basic-nav-dropdown">
          <NavDropdown.Item href="/">Sayur</NavDropdown.Item>
          <NavDropdown.Item href="/buah">Buah</NavDropdown.Item>
          <NavDropdown.Item href="/bumbu">Bumbu</NavDropdown.Item>
        </NavDropdown>
      </Nav>
    </Navbar.Collapse>
  </Container>
</Navbar>
    );
}

export default navbar
