import react, { Component } from "react";
import ReactDOM from "react-dom";

class UTS extends Component {
    render() {
        return <h1>UTS</h1>
    }
}

export default ClassKomponen