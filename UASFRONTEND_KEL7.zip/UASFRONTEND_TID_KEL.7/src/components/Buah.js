import { Card, Row, Col } from 'react-bootstrap';
import buah1 from './apel.jpg';
import buah2 from './strawberry.png';

const buah = () => {
    return(
        <Row xs={1} md={2} className="g-4">
            {Array.from({ length: 2 }).map((_, idx) => (
            <Col>
            <Card>
                <Card.Img variant="top" src={buah1} />
                <Card.Body>
                    <Card.Title>Apel</Card.Title>
                    <Card.Text>
                        <p>12.00/biji</p>
                        <p>Bu Santi</p>
                        <p>23/12/2021</p>
                    </Card.Text>
                </Card.Body>
                <Card.Img variant="secondary" src={buah2} />
                <Card.Body>
                    <Card.Title>Kentang</Card.Title>
                    <Card.Text>
                        <p>3.000/biji</p>
                        <p>Bu Sari</p>
                        <p>23/12/2021</p>
                    </Card.Text>
                </Card.Body>
            </Card>
            </Col>
            ))}
        </Row>
    );
}

export default buah