import react from "react";

/*function Komponen1(){
    return <h1>Tes komponen</h1>
}*/

export const Komponen1 = () => <h1>Bahasa Yang Saat ini  Digunakan Dalam Perkuliahan TI </h1>


export default Komponen1