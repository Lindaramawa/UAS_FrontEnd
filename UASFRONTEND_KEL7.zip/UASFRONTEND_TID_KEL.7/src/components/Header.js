import { Carousel } from "react-bootstrap";
import gbr1 from './sayur.png';
import gbr2 from './buah.jpg';
import gbr3 from './bumbu.jpg';

const header = () => {
    return(
        <Carousel variant="dark">
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={gbr1}
      alt="First slide"
    />
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={gbr2}
      alt="Second slide"
    />
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      src={gbr3}
      alt="Third slide"
    />
  </Carousel.Item>
</Carousel>
    );
}

export default header